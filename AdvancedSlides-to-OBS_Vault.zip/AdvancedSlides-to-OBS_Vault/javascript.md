
a javascript API is available in Reveal JS and OBS Browser to automate a slide show. 

