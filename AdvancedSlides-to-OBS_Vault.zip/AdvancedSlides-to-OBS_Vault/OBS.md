Open Broadcast Studio (OBS) is an open source project that combines sources (Audio, Camera, Windows, Games, Browser, Mouse, Keyboard) for recording, streaming or live presentation. 

