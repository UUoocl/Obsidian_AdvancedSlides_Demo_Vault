```
---
title: Slide and Scene Changer
margin: .04
width: 1280
height: 720
navigationMode: 'linear'
controls: true
controlsLayout: 'bottom-right'
cssclass: "ExternalCSS-file"
autoSlideStoppable: false
transition: none
bg: transparent
---

```

