### Slide Background options

#### Background color

<!-- slide bg="transparent" -->
<!-- slide bg="aquamarine" -->
<!-- slide bg="#ff0000" -->
<!-- slide bg="rgb(70, 70, 255)" -->
<!-- slide bg="hsla(315, 100%, 50%, 1)" -->

#### Background images
<!-- slide bg="https://picsum.photos/seed/picsum/800/600" -->
<!-- slide bg="[[image.jpg]]" -->
<!-- slide bg="https://picsum.photos/seed/picsum/800/600" data-background-opacity="0.5" -->

First Header | Second Header
------------ | ------------
Content from cell 1 | Content from cell 2
Content in the first column | Content in the second column

### Slide Background Transitions

<!-- slide data-transition="zoom" -->