
Node.js® is an open-source, cross-platform [[JavaScript]] runtime environment.