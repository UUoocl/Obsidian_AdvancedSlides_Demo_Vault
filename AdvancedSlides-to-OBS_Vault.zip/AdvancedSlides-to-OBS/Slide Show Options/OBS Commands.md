#### global options
<!-- .slide: data-on-obs-scene-change= true -->
<!-- .slide: data-overview-shown= "scene name" -->

#### slide commands
<!-- .slide: data-slide-changed="scene name" -->
<!-- .slide: data-slide-transitioned="scene name" -->
<!-- .slide: data-slide-name="scene name" -->

#### Fragment commands
<!-- element class data-fragment-shown="scene name" -->
<!-- element class data-fragment-hidden="scene name" -->



