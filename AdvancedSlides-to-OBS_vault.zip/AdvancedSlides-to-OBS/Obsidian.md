
Obsidian is a note making app that links notes to create a knowledge management system.
Obsidian is an [[electron]] app.

Obsidian's appearance can be customized through [[CSS snippets]] or themes. 