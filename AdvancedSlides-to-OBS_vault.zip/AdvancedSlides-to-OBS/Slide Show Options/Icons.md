[Icons — Advanced Slides Documentation (mszturc.github.io)](https://mszturc.github.io/obsidian-advanced-slides/extend-syntax/fontawesome/)

```
:smile: => 😄
```




### Free Emojis and icons


[Sidebars icons file - Share & showcase - Obsidian Forum](https://forum.obsidian.md/t/sidebars-icons-file/46684/2)

https://openmoji.org/
Emoji Icons as SVGs

[Full Emoji List, v15.0 (unicode.org)](https://unicode.org/emoji/charts/full-emoji-list.html)

[Lucide](https://lucide.dev/)

https://emojipedia.org/


All emojis designed by [OpenMoji](https://openmoji.org/) – the open-source emoji and icon project. License: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/#)

