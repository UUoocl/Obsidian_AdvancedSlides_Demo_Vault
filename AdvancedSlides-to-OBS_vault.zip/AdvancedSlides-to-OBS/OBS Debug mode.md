Launch [[OBS]] (64).exe with **"--remote-debugging-port=9222"** then open your local chrome and go to "localhost:9222".
```
"C:\Program Files\obs-studio\bin\64bit\obs64.exe --remote-debugging-port=9222"
```


